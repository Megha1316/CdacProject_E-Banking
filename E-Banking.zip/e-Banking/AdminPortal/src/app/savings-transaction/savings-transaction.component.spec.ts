/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SavingsTransactionComponent } from './savings-transaction.component';

describe('Component: SavingsTransaction', () => {
  it('should create an instance', () => {
    let component = new SavingsTransactionComponent();
    expect(component).toBeTruthy();
  });
});
